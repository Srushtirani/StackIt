import { useState } from "react";
import { useParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { CalendarDays, MapPin, Link as LinkIcon, Mail, Award, ChevronUp, MessageSquare, Bookmark } from "lucide-react";
import { Navbar } from "@/components/Navbar";

// Mock user data
const userData = {
  id: "1",
  name: "John Developer",
  username: "johndeveloper",
  bio: "Full-stack developer with 5+ years of experience in React, Node.js, and SQL databases. Love helping others solve coding problems!",
  email: "john@example.com",
  website: "https://johndeveloper.com",
  location: "San Francisco, CA",
  joinDate: "January 2020",
  reputation: 2547,
  badges: {
    gold: 3,
    silver: 12,
    bronze: 28
  },
  stats: {
    questionsAsked: 15,
    answersPosted: 87,
    bookmarked: 23
  }
};

// Mock questions and answers data
const askedQuestions = [
  {
    id: "1",
    title: "How to optimize React component re-renders?",
    score: 12,
    answers: 5,
    views: 342,
    tags: ["react", "performance", "optimization"],
    timeAgo: "2 days ago"
  },
  {
    id: "2", 
    title: "Best practices for SQL database indexing",
    score: 8,
    answers: 3,
    views: 189,
    tags: ["sql", "database", "indexing"],
    timeAgo: "1 week ago"
  }
];

const postedAnswers = [
  {
    id: "1",
    questionTitle: "How to handle async operations in React?",
    score: 15,
    accepted: true,
    timeAgo: "3 days ago"
  },
  {
    id: "2",
    questionTitle: "Understanding JavaScript closures",
    score: 8,
    accepted: false,
    timeAgo: "1 week ago"
  }
];

const bookmarkedQuestions = [
  {
    id: "1",
    title: "Advanced TypeScript patterns and techniques",
    score: 25,
    answers: 8,
    tags: ["typescript", "patterns"],
    timeAgo: "bookmarked 2 days ago"
  }
];

export const UserProfile = () => {
  const { userId } = useParams();
  const [activeTab, setActiveTab] = useState("questions");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* User Info Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-card border-border">
              <CardContent className="p-6">
                {/* Avatar and basic info */}
                <div className="text-center mb-6">
                  <Avatar className="w-24 h-24 mx-auto mb-4">
                    <AvatarImage src="/placeholder.svg" alt={userData.name} />
                    <AvatarFallback className="text-xl bg-primary text-primary-foreground">
                      {userData.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <h1 className="text-2xl font-bold text-foreground">{userData.name}</h1>
                  <p className="text-muted-foreground">@{userData.username}</p>
                </div>

                {/* Bio */}
                {userData.bio && (
                  <div className="mb-6">
                    <p className="text-foreground text-sm leading-relaxed">{userData.bio}</p>
                  </div>
                )}

                {/* Contact info */}
                <div className="space-y-3 mb-6">
                  {userData.location && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{userData.location}</span>
                    </div>
                  )}
                  {userData.website && (
                    <div className="flex items-center gap-2 text-sm">
                      <LinkIcon className="h-4 w-4 text-muted-foreground" />
                      <a href={userData.website} target="_blank" rel="noopener noreferrer" 
                         className="text-primary hover:text-primary-glow">
                        {userData.website.replace('https://', '')}
                      </a>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CalendarDays className="h-4 w-4" />
                    <span>Joined {userData.joinDate}</span>
                  </div>
                </div>

                {/* Reputation */}
                <div className="mb-6">
                  <h3 className="font-semibold text-foreground mb-3">Reputation</h3>
                  <div className="text-2xl font-bold text-primary">{userData.reputation.toLocaleString()}</div>
                </div>

                {/* Badges */}
                <div className="mb-6">
                  <h3 className="font-semibold text-foreground mb-3">Badges</h3>
                  <div className="flex gap-4">
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <span className="text-sm text-foreground">{userData.badges.gold}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-3 rounded-full bg-gray-400"></div>
                      <span className="text-sm text-foreground">{userData.badges.silver}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-3 h-3 rounded-full bg-amber-600"></div>
                      <span className="text-sm text-foreground">{userData.badges.bronze}</span>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div>
                  <h3 className="font-semibold text-foreground mb-3">Activity</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Questions asked</span>
                      <span className="text-foreground font-medium">{userData.stats.questionsAsked}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Answers posted</span>
                      <span className="text-foreground font-medium">{userData.stats.answersPosted}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Bookmarked</span>
                      <span className="text-foreground font-medium">{userData.stats.bookmarked}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger value="questions">Asked Questions</TabsTrigger>
                <TabsTrigger value="answers">Posted Answers</TabsTrigger>
                <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
              </TabsList>

              {/* Asked Questions Tab */}
              <TabsContent value="questions" className="space-y-4">
                {askedQuestions.map((question) => (
                  <Card key={question.id} className="question-card">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="flex flex-col items-center gap-1 text-sm text-muted-foreground min-w-[60px]">
                          <div className="flex items-center gap-1">
                            <ChevronUp className="h-4 w-4" />
                            <span>{question.score}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageSquare className="h-4 w-4" />
                            <span>{question.answers}</span>
                          </div>
                          <div className="text-xs">{question.views} views</div>
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground hover:text-primary cursor-pointer mb-2">
                            {question.title}
                          </h3>
                          <div className="flex flex-wrap gap-2 mb-2">
                            {question.tags.map((tag) => (
                              <Badge key={tag} className="tag text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            asked {question.timeAgo}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Posted Answers Tab */}
              <TabsContent value="answers" className="space-y-4">
                {postedAnswers.map((answer) => (
                  <Card key={answer.id} className="question-card">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="flex flex-col items-center gap-1 text-sm min-w-[60px]">
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <ChevronUp className="h-4 w-4" />
                            <span>{answer.score}</span>
                          </div>
                          {answer.accepted && (
                            <Badge className="bg-success text-success-foreground text-xs px-1 py-0.5">
                              ✓ Accepted
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground hover:text-primary cursor-pointer mb-2">
                            {answer.questionTitle}
                          </h3>
                          <div className="text-sm text-muted-foreground">
                            answered {answer.timeAgo}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Bookmarks Tab */}
              <TabsContent value="bookmarks" className="space-y-4">
                {bookmarkedQuestions.map((question) => (
                  <Card key={question.id} className="question-card">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="flex flex-col items-center gap-1 text-sm text-muted-foreground min-w-[60px]">
                          <div className="flex items-center gap-1">
                            <ChevronUp className="h-4 w-4" />
                            <span>{question.score}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageSquare className="h-4 w-4" />
                            <span>{question.answers}</span>
                          </div>
                          <Bookmark className="h-4 w-4 text-primary" />
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground hover:text-primary cursor-pointer mb-2">
                            {question.title}
                          </h3>
                          <div className="flex flex-wrap gap-2 mb-2">
                            {question.tags.map((tag) => (
                              <Badge key={tag} className="tag text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {question.timeAgo}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};