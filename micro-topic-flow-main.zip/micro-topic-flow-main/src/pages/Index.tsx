import { TrendingUp, Users, MessageSquare, Award, ArrowRight, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Navbar } from "@/components/Navbar";

const Index = () => {
  const featuredQuestions = [
    {
      id: 1,
      title: "How to optimize React performance with large datasets?",
      votes: 24,
      answers: 8,
      tags: ["React", "Performance", "JavaScript"]
    },
    {
      id: 2,
      title: "Best practices for API design in REST",
      votes: 18,
      answers: 12,
      tags: ["API", "REST", "Backend"]
    },
    {
      id: 3,
      title: "Understanding async/await vs Promises in JavaScript",
      votes: 31,
      answers: 6,
      tags: ["JavaScript", "Async", "Promises"]
    }
  ];

  const stats = [
    { label: "Questions", value: "2.1M", icon: MessageSquare },
    { label: "Users", value: "456K", icon: Users },
    { label: "Answers", value: "5.8M", icon: Star },
    { label: "Expert Contributors", value: "12K", icon: Award }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-card to-card-elevated">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl font-bold bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent">
                Every developer has a
                <span className="block bg-gradient-primary bg-clip-text text-transparent">
                  tab open to StackIt
                </span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Get unstuck with help from millions of developers. Share knowledge, build your reputation, 
                and advance your career in the world's largest developer community.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="gradient" size="lg" asChild>
                <Link to="/questions">
                  Browse Questions
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link to="/ask">Ask a Question</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center space-y-2">
                  <Icon className="w-8 h-8 mx-auto text-primary" />
                  <div className="text-3xl font-bold">{stat.value}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Questions */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl font-bold">Trending Questions</h2>
            <p className="text-muted-foreground">
              Popular questions from the community this week
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredQuestions.map((question) => (
              <Card key={question.id} className="question-card">
                <CardHeader>
                  <CardTitle className="text-lg leading-tight">
                    <Link 
                      to={`/questions/${question.id}`}
                      className="hover:text-primary transition-colors"
                    >
                      {question.title}
                    </Link>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <TrendingUp className="w-4 h-4" />
                        {question.votes} votes
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-4 h-4" />
                        {question.answers} answers
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {question.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="tag">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Button variant="outline" asChild>
              <Link to="/questions">View All Questions</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-primary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-white">
              Ready to share your knowledge?
            </h2>
            <p className="text-xl text-white/90">
              Join thousands of developers helping each other solve problems.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="secondary" size="lg" asChild>
                <Link to="/register">Sign Up Today</Link>
              </Button>
              <Button variant="outline" size="lg" className="text-white border-white hover:bg-white hover:text-primary" asChild>
                <Link to="/ask">Ask Your First Question</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
