import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ChevronUp, ChevronDown, MessageSquare, Bookmark, Share2, Bold, Italic, Check } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { toast } from "@/hooks/use-toast";

// Mock data
const questionData = {
  id: "1",
  title: "How to join 2 columns in a data set to make a separate column in SQL",
  content: "I do not know the code for it as I am a beginner. As an example what I need to do is like there is a column 1 containing First name, and column 2 consists of last name I want a column to combine...",
  author: "User Name",
  score: 5,
  answers: 2,
  views: 145,
  timeAgo: "5 ans",
  tags: ["SQL", "Database"]
};

const answersData = [
  {
    id: "1",
    content: "The || Operator.\nThe & Operator.\nThe CONCAT Function.",
    author: "Expert Developer",
    score: 3,
    timeAgo: "3 ans",
    isAccepted: true
  },
  {
    id: "2", 
    content: "You can use the CONCAT function in SQL to combine multiple columns. Here's the syntax: SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM your_table;",
    author: "SQL Master",
    score: 1,
    timeAgo: "2 ans",
    isAccepted: false
  }
];

export const QuestionDetail = () => {
  const { id } = useParams();
  const [newAnswer, setNewAnswer] = useState("");
  const [questionVote, setQuestionVote] = useState(0);
  const [answerVotes, setAnswerVotes] = useState<{[key: string]: number}>({});

  const handleVote = (type: 'question' | 'answer', id: string, direction: 'up' | 'down') => {
    if (type === 'question') {
      setQuestionVote(prev => direction === 'up' ? prev + 1 : prev - 1);
    } else {
      setAnswerVotes(prev => ({
        ...prev,
        [id]: (prev[id] || 0) + (direction === 'up' ? 1 : -1)
      }));
    }
  };

  const handleSubmitAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnswer.trim()) return;
    
    toast({
      title: "Success",
      description: "Your answer has been submitted!",
    });
    setNewAnswer("");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Breadcrumb */}
        <div className="mb-4">
          <Link to="/questions" className="text-primary hover:text-primary-glow text-sm">
            Question
          </Link>
          <span className="text-muted-foreground text-sm mx-2">›</span>
          <span className="text-foreground text-sm">How to join 2...</span>
        </div>

        {/* Question */}
        <Card className="bg-card border-border mb-6">
          <CardContent className="p-6">
            <div className="flex gap-4">
              {/* Vote buttons */}
              <div className="flex flex-col items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="vote-button"
                  onClick={() => handleVote('question', '1', 'up')}
                >
                  <ChevronUp className="h-5 w-5" />
                </Button>
                <span className="text-xl font-bold text-foreground">
                  {questionData.score + questionVote}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="vote-button"
                  onClick={() => handleVote('question', '1', 'down')}
                >
                  <ChevronDown className="h-5 w-5" />
                </Button>
              </div>

              {/* Question content */}
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-foreground mb-4">
                  {questionData.title}
                </h1>
                <p className="text-foreground mb-4 leading-relaxed">
                  {questionData.content}
                </p>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {questionData.tags.map((tag) => (
                    <Badge key={tag} className="tag">
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Question meta */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                      <Bookmark className="h-4 w-4 mr-1" />
                      Bookmark
                    </Button>
                    <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                      <Share2 className="h-4 w-4 mr-1" />
                      Share
                    </Button>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <span className="text-primary">👤 {questionData.author}</span>
                    <span className="mx-2">•</span>
                    <span>{questionData.timeAgo}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Answers */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-foreground mb-4">
            Answers ({answersData.length})
          </h2>
          
          <div className="space-y-4">
            {answersData.map((answer) => (
              <Card key={answer.id} className={`bg-card border-border ${answer.isAccepted ? 'border-success/50' : ''}`}>
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    {/* Vote buttons */}
                    <div className="flex flex-col items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="vote-button"
                        onClick={() => handleVote('answer', answer.id, 'up')}
                      >
                        <ChevronUp className="h-5 w-5" />
                      </Button>
                      <span className="text-xl font-bold text-foreground">
                        {answer.score + (answerVotes[answer.id] || 0)}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="vote-button"
                        onClick={() => handleVote('answer', answer.id, 'down')}
                      >
                        <ChevronDown className="h-5 w-5" />
                      </Button>
                      {answer.isAccepted && (
                        <div className="w-8 h-8 rounded-full bg-success flex items-center justify-center mt-2">
                          <Check className="h-4 w-4 text-success-foreground" />
                        </div>
                      )}
                    </div>

                    {/* Answer content */}
                    <div className="flex-1">
                      <div className="text-foreground mb-4 whitespace-pre-line leading-relaxed">
                        {answer.content}
                      </div>
                      
                      <div className="flex items-center justify-end">
                        <div className="text-sm text-muted-foreground">
                          <span className="text-primary">👤 {answer.author}</span>
                          <span className="mx-2">•</span>
                          <span>{answer.timeAgo}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Submit Answer */}
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Submit Your Answer</h3>
            
            <form onSubmit={handleSubmitAnswer}>
              {/* Text editor toolbar */}
              <div className="flex items-center gap-1 p-2 bg-muted rounded-t-md border border-border border-b-0 mb-0">
                <Button type="button" variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <Bold className="h-4 w-4" />
                </Button>
                <Button type="button" variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <Italic className="h-4 w-4" />
                </Button>
              </div>
              
              <Textarea
                placeholder="Write your answer here..."
                value={newAnswer}
                onChange={(e) => setNewAnswer(e.target.value)}
                className="min-h-[200px] bg-input border-border text-foreground placeholder:text-muted-foreground rounded-t-none mb-4"
              />
              
              <div className="flex justify-end">
                <Button 
                  type="submit"
                  className="bg-primary hover:bg-primary-glow text-primary-foreground"
                >
                  Submit Answer
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};