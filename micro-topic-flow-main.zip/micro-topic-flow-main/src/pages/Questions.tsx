import { useState } from "react";
import { ChevronUp, ChevronDown, MessageSquare, Eye, Clock, Tag } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Question {
  id: number;
  title: string;
  excerpt: string;
  votes: number;
  answers: number;
  views: number;
  tags: string[];
  author: string;
  timeAgo: string;
  hasAcceptedAnswer: boolean;
}

const mockQuestions: Question[] = [
  {
    id: 1,
    title: "How to join 2 columns in a data set to make a separate column in SQL",
    excerpt: "I do not know the code for it as I am a beginner. As an example what I need to do is like there is a column 1 containing First name, and column 2 consists of last name I want a column to combine both.",
    votes: 5,
    answers: 4,
    views: 142,
    tags: ["SQL", "Database"],
    author: "User Name",
    timeAgo: "5 ans",
    hasAcceptedAnswer: true
  },
  {
    id: 2,
    title: "React useState hook not updating state immediately",
    excerpt: "I'm having trouble with useState not updating immediately after setState call. The component doesn't re-render with the new value...",
    votes: 12,
    answers: 3,
    views: 89,
    tags: ["React", "JavaScript", "Hooks"],
    author: "Developer123",
    timeAgo: "3 ans",
    hasAcceptedAnswer: false
  },
  {
    id: 3,
    title: "Best practices for handling authentication in Node.js",
    excerpt: "What are the current best practices for implementing user authentication in a Node.js application? Should I use JWT tokens or sessions?",
    votes: 8,
    answers: 2,
    views: 156,
    tags: ["Node.js", "Authentication", "JWT"],
    author: "BackendDev",
    timeAgo: "2 ans",
    hasAcceptedAnswer: false
  }
];

export const Questions = () => {
  const [questions] = useState<Question[]>(mockQuestions);
  const [sortBy, setSortBy] = useState("newest");

  const QuestionCard = ({ question }: { question: Question }) => (
    <Card className="question-card">
      <div className="flex gap-4">
        {/* Vote/Stats Column */}
        <div className="flex flex-col items-center space-y-2 min-w-[80px]">
          <div className="flex flex-col items-center">
            <Button variant="ghost" size="icon" className="vote-button">
              <ChevronUp className="w-5 h-5" />
            </Button>
            <span className="text-lg font-semibold">{question.votes}</span>
            <Button variant="ghost" size="icon" className="vote-button">
              <ChevronDown className="w-5 h-5" />
            </Button>
          </div>
          
          <div className="flex flex-col items-center text-sm space-y-1">
            <div className={`flex items-center gap-1 ${question.hasAcceptedAnswer ? 'text-success' : 'text-muted-foreground'}`}>
              <MessageSquare className="w-4 h-4" />
              <span>{question.answers}</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Eye className="w-4 h-4" />
              <span>{question.views}</span>
            </div>
          </div>
        </div>

        {/* Content Column */}
        <div className="flex-1 space-y-3">
          <Link 
            to={`/questions/${question.id}`}
            className="block"
          >
            <h3 className="text-lg font-semibold text-foreground hover:text-primary transition-colors">
              {question.title}
            </h3>
          </Link>
          
          <p className="text-muted-foreground text-sm line-clamp-2">
            {question.excerpt}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex flex-wrap gap-2">
              {question.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="tag">
                  {tag}
                </Badge>
              ))}
            </div>
            
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>asked {question.timeAgo} by</span>
              <Link to={`/users/${question.author}`} className="text-primary hover:underline">
                {question.author}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">All Questions</h1>
            <p className="text-muted-foreground mt-1">
              {questions.length} questions
            </p>
          </div>
          <Button variant="gradient" asChild>
            <Link to="/ask">Ask New Question</Link>
          </Button>
        </div>

        {/* Filter Tabs */}
        <Tabs value={sortBy} onValueChange={setSortBy} className="w-full">
          <div className="flex items-center justify-between">
            <TabsList className="grid w-auto grid-cols-3">
              <TabsTrigger value="newest">Newest</TabsTrigger>
              <TabsTrigger value="unanswered">Unanswered</TabsTrigger>
              <TabsTrigger value="more">More</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="newest" className="space-y-4 mt-6">
            {questions.map((question) => (
              <QuestionCard key={question.id} question={question} />
            ))}
          </TabsContent>

          <TabsContent value="unanswered" className="space-y-4 mt-6">
            {questions
              .filter((q) => q.answers === 0 || !q.hasAcceptedAnswer)
              .map((question) => (
                <QuestionCard key={question.id} question={question} />
              ))}
          </TabsContent>

          <TabsContent value="more" className="space-y-4 mt-6">
            <div className="text-center py-8 text-muted-foreground">
              <Tag className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>Additional sorting options coming soon...</p>
            </div>
          </TabsContent>
        </Tabs>

        {/* Pagination */}
        <div className="flex items-center justify-center space-x-2 pt-8">
          <Button variant="outline" size="sm">Previous</Button>
          {[1, 2, 3, 4, 5].map((page) => (
            <Button
              key={page}
              variant={page === 1 ? "default" : "outline"}
              size="sm"
              className="w-8"
            >
              {page}
            </Button>
          ))}
          <Button variant="outline" size="sm">Next</Button>
        </div>
      </div>
    </div>
  );
};