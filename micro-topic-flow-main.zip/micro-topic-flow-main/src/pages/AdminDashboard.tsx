import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Shield, 
  Flag, 
  Users, 
  Search, 
  MoreHorizontal, 
  Ban, 
  CheckCircle, 
  XCircle,
  TrendingUp,
  MessageSquare,
  Eye
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { toast } from "@/hooks/use-toast";

// Mock reported content data
const reportedContent = [
  {
    id: "1",
    type: "question",
    title: "How to hack into someone's account?",
    author: "suspicious_user",
    reportReason: "Inappropriate content",
    reportedBy: "concerned_user",
    status: "pending",
    timeAgo: "2 hours ago",
    reports: 3
  },
  {
    id: "2",
    type: "answer",
    title: "Answer containing spam links",
    author: "spammer123",
    reportReason: "Spam",
    reportedBy: "moderator1",
    status: "pending",
    timeAgo: "4 hours ago",
    reports: 5
  },
  {
    id: "3",
    type: "comment",
    title: "Offensive comment on React tutorial",
    author: "rude_user",
    reportReason: "Harassment",
    reportedBy: "affected_user",
    status: "resolved",
    timeAgo: "1 day ago",
    reports: 2
  }
];

// Mock users data
const usersData = [
  {
    id: "1",
    name: "John Developer",
    username: "johndeveloper",
    email: "john@example.com",
    reputation: 2547,
    joinDate: "Jan 2020",
    status: "active",
    questionsAsked: 15,
    answersPosted: 87,
    lastActive: "2 hours ago"
  },
  {
    id: "2",
    name: "Jane Smith",
    username: "janesmith",
    email: "jane@example.com",
    reputation: 1823,
    joinDate: "Mar 2021",
    status: "active",
    questionsAsked: 28,
    answersPosted: 45,
    lastActive: "1 day ago"
  },
  {
    id: "3",
    name: "Spam User",
    username: "spammer123",
    email: "spam@example.com",
    reputation: -25,
    joinDate: "Dec 2024",
    status: "suspended",
    questionsAsked: 0,
    answersPosted: 12,
    lastActive: "5 days ago"
  }
];

// Mock stats data
const statsData = {
  totalUsers: 1247,
  activeToday: 89,
  totalQuestions: 3421,
  totalAnswers: 8932,
  pendingReports: 8,
  resolvedReports: 156
};

export const AdminDashboard = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [reportedItems, setReportedItems] = useState(reportedContent);
  const [users, setUsers] = useState(usersData);

  const handleResolveReport = (id: string, action: 'approve' | 'remove') => {
    setReportedItems(prev => 
      prev.map(item => 
        item.id === id 
          ? { ...item, status: action === 'approve' ? 'resolved' : 'removed' }
          : item
      )
    );
    
    toast({
      title: "Success",
      description: `Report ${action === 'approve' ? 'approved' : 'removed'} successfully`,
    });
  };

  const handleUserAction = (userId: string, action: 'suspend' | 'activate' | 'ban') => {
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, status: action === 'activate' ? 'active' : action }
          : user
      )
    );
    
    toast({
      title: "Success",
      description: `User ${action}ed successfully`,
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-warning text-warning-foreground">Pending</Badge>;
      case 'resolved':
        return <Badge className="bg-success text-success-foreground">Resolved</Badge>;
      case 'removed':
        return <Badge className="bg-destructive text-destructive-foreground">Removed</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getUserStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-success text-success-foreground">Active</Badge>;
      case 'suspended':
        return <Badge className="bg-warning text-warning-foreground">Suspended</Badge>;
      case 'banned':
        return <Badge className="bg-destructive text-destructive-foreground">Banned</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Shield className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold text-foreground">Admin Dashboard</h1>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Total Users</p>
                  <p className="text-xl font-bold text-foreground">{statsData.totalUsers.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-success" />
                <div>
                  <p className="text-sm text-muted-foreground">Active Today</p>
                  <p className="text-xl font-bold text-foreground">{statsData.activeToday}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Questions</p>
                  <p className="text-xl font-bold text-foreground">{statsData.totalQuestions.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-success" />
                <div>
                  <p className="text-sm text-muted-foreground">Answers</p>
                  <p className="text-xl font-bold text-foreground">{statsData.totalAnswers.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Flag className="h-5 w-5 text-warning" />
                <div>
                  <p className="text-sm text-muted-foreground">Pending Reports</p>
                  <p className="text-xl font-bold text-foreground">{statsData.pendingReports}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-success" />
                <div>
                  <p className="text-sm text-muted-foreground">Resolved</p>
                  <p className="text-xl font-bold text-foreground">{statsData.resolvedReports}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="reports" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <Flag className="h-4 w-4" />
              Reported Content
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Manage Users
            </TabsTrigger>
          </TabsList>

          {/* Reported Content Tab */}
          <TabsContent value="reports">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-foreground">Reported Content</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reportedItems.map((item) => (
                    <div 
                      key={item.id} 
                      className="flex items-center justify-between p-4 bg-accent/20 rounded-lg border border-border"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="text-xs">
                            {item.type}
                          </Badge>
                          {getStatusBadge(item.status)}
                          <span className="text-sm text-muted-foreground">
                            {item.reports} reports
                          </span>
                        </div>
                        <h4 className="font-semibold text-foreground mb-1">
                          {item.title}
                        </h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          By: <span className="text-foreground">{item.author}</span> • 
                          Reported by: <span className="text-foreground">{item.reportedBy}</span> • 
                          Reason: <span className="text-foreground">{item.reportReason}</span>
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {item.timeAgo}
                        </p>
                      </div>
                      
                      {item.status === 'pending' && (
                        <div className="flex items-center gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="border-border hover:bg-accent"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-success hover:bg-success/90 text-success-foreground"
                            onClick={() => handleResolveReport(item.id, 'approve')}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => handleResolveReport(item.id, 'remove')}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Remove
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Management Tab */}
          <TabsContent value="users">
            <Card className="bg-card border-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-foreground">Manage Users</CardTitle>
                  <div className="relative w-72">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input 
                      placeholder="Search users..." 
                      className="pl-10 bg-input border-border"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredUsers.map((user) => (
                    <div 
                      key={user.id} 
                      className="flex items-center justify-between p-4 bg-accent/20 rounded-lg border border-border"
                    >
                      <div className="flex items-center gap-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src="/placeholder.svg" alt={user.name} />
                          <AvatarFallback className="bg-primary text-primary-foreground">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold text-foreground">{user.name}</h4>
                            {getUserStatusBadge(user.status)}
                          </div>
                          <p className="text-sm text-muted-foreground mb-1">
                            @{user.username} • {user.email}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Reputation: <span className="text-foreground font-medium">{user.reputation.toLocaleString()}</span></span>
                            <span>Questions: <span className="text-foreground font-medium">{user.questionsAsked}</span></span>
                            <span>Answers: <span className="text-foreground font-medium">{user.answersPosted}</span></span>
                            <span>Joined: <span className="text-foreground font-medium">{user.joinDate}</span></span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {user.status === 'active' ? (
                          <>
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="border-warning text-warning hover:bg-warning/10"
                              onClick={() => handleUserAction(user.id, 'suspend')}
                            >
                              Suspend
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleUserAction(user.id, 'ban')}
                            >
                              <Ban className="h-4 w-4 mr-1" />
                              Ban
                            </Button>
                          </>
                        ) : (
                          <Button 
                            size="sm" 
                            className="bg-success hover:bg-success/90 text-success-foreground"
                            onClick={() => handleUserAction(user.id, 'activate')}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Activate
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};