import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Check, CheckCheck, MessageSquare, ThumbsUp, Award, User } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { toast } from "@/hooks/use-toast";

// Mock notifications data
const notificationsData = [
  {
    id: "1",
    type: "answer",
    title: "New answer on your question",
    message: "Expert Developer answered your question about SQL joins",
    questionTitle: "How to join 2 columns in a data set to make a separate column in SQL",
    read: false,
    timeAgo: "2 hours ago",
    icon: MessageSquare
  },
  {
    id: "2",
    type: "upvote",
    title: "Your answer received an upvote",
    message: "Your answer about React hooks got upvoted",
    questionTitle: "Understanding useEffect hook in React",
    read: false,
    timeAgo: "4 hours ago",
    icon: ThumbsUp
  },
  {
    id: "3",
    type: "accepted",
    title: "Your answer was accepted",
    message: "John Smith accepted your answer",
    questionTitle: "Best practices for database optimization",
    read: true,
    timeAgo: "1 day ago",
    icon: Check
  },
  {
    id: "4",
    type: "badge",
    title: "Badge earned",
    message: "You earned the 'Helpful' badge for getting 10 upvotes on answers",
    read: true,
    timeAgo: "2 days ago",
    icon: Award
  },
  {
    id: "5",
    type: "mention",
    title: "You were mentioned",
    message: "Sarah mentioned you in a comment",
    questionTitle: "JavaScript async/await best practices",
    read: false,
    timeAgo: "3 days ago",
    icon: User
  }
];

export const Notifications = () => {
  const [notifications, setNotifications] = useState(notificationsData);

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, read: true }))
    );
    toast({
      title: "Success",
      description: "All notifications marked as read",
    });
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const getNotificationBg = (type: string, read: boolean) => {
    if (!read) {
      switch (type) {
        case "answer":
          return "bg-primary/5 border-primary/20";
        case "upvote":
          return "bg-success/5 border-success/20";
        case "accepted":
          return "bg-success/5 border-success/20";
        case "badge":
          return "bg-warning/5 border-warning/20";
        case "mention":
          return "bg-primary/5 border-primary/20";
        default:
          return "bg-card border-border";
      }
    }
    return "bg-card border-border";
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case "answer":
        return "text-primary";
      case "upvote":
        return "text-success";
      case "accepted":
        return "text-success";
      case "badge":
        return "text-warning";
      case "mention":
        return "text-primary";
      default:
        return "text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="h-6 w-6 text-primary" />
                <CardTitle className="text-2xl text-foreground">Notifications</CardTitle>
                {unreadCount > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {unreadCount} new
                  </Badge>
                )}
              </div>
              {unreadCount > 0 && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={markAllAsRead}
                  className="border-border hover:bg-accent"
                >
                  <CheckCheck className="h-4 w-4 mr-2" />
                  Mark all as read
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {notifications.length === 0 ? (
              <div className="text-center py-12">
                <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No notifications yet</h3>
                <p className="text-muted-foreground">
                  When you get upvotes, answers, comments, and other activity, it will show up here.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {notifications.map((notification) => {
                  const IconComponent = notification.icon;
                  return (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-accent/50 transition-colors cursor-pointer ${getNotificationBg(notification.type, notification.read)}`}
                      onClick={() => !notification.read && markAsRead(notification.id)}
                    >
                      <div className="flex gap-4">
                        <div className={`flex-shrink-0 ${getIconColor(notification.type)}`}>
                          <IconComponent className="h-5 w-5" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <h4 className="font-semibold text-foreground mb-1">
                                {notification.title}
                              </h4>
                              <p className="text-sm text-muted-foreground mb-2">
                                {notification.message}
                              </p>
                              {notification.questionTitle && (
                                <p className="text-sm text-primary hover:text-primary-glow font-medium">
                                  "{notification.questionTitle}"
                                </p>
                              )}
                            </div>
                            
                            <div className="flex items-center gap-2">
                              {!notification.read && (
                                <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></div>
                              )}
                              <span className="text-xs text-muted-foreground whitespace-nowrap">
                                {notification.timeAgo}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};