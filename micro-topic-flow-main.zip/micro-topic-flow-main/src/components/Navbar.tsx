import { Search, Bell, Plus, User } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Navbar = () => {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">S</span>
            </div>
            <span className="text-xl font-bold">StackIt</span>
          </Link>
          
          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`text-sm font-medium transition-colors hover:text-primary ${
                isActive('/') ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/questions" 
              className={`text-sm font-medium transition-colors hover:text-primary ${
                isActive('/questions') ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Questions
            </Link>
            <Link 
              to="/tags" 
              className={`text-sm font-medium transition-colors hover:text-primary ${
                isActive('/tags') ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Tags
            </Link>
            <Link 
              to="/users" 
              className={`text-sm font-medium transition-colors hover:text-primary ${
                isActive('/users') ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Users
            </Link>
          </div>
          
          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input 
                placeholder="Search questions, tags, or users..." 
                className="pl-10 bg-card border-border"
              />
            </div>
          </div>
          
          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <Button variant="ghost" size="icon" className="relative" asChild>
              <Link to="/notifications">
                <Bell className="w-5 h-5" />
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 w-5 h-5 text-xs p-0 flex items-center justify-center"
                >
                  3
                </Badge>
              </Link>
            </Button>
            
            {/* Ask Question */}
            <Button variant="gradient" size="sm" asChild>
              <Link to="/ask">
                <Plus className="w-4 h-4 mr-1" />
                Ask Question
              </Link>
            </Button>
            
            {/* User Menu */}
            <Button variant="ghost" size="icon" asChild>
              <Link to="/profile/1">
                <User className="w-5 h-5" />
              </Link>
            </Button>
            
            {/* Login Button (when not authenticated) */}
            <Button variant="outline" size="sm" asChild>
              <Link to="/login">Login</Link>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};